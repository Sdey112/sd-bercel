const express = require('express');
const multer = require('multer');
const cors = require('cors');
const fs = require('fs');
const path = require('path');
const { exec } = require('child_process');
const stripe = require('stripe')('sk_test_your_stripe_secret_key');

const app = express();
const port = process.env.PORT || 5000;

app.use(cors());
app.use(express.json());

const upload = multer({ dest: 'uploads/' });
let paidVideos = new Set();

app.post('/api/create-payment-intent', async (req, res) => {
  const paymentIntent = await stripe.paymentIntents.create({
    amount: 300,
    currency: 'usd',
    automatic_payment_methods: { enabled: true },
  });
  res.send({ clientSecret: paymentIntent.client_secret });
});

app.post('/api/confirm-payment', async (req, res) => {
  const { paymentId } = req.body;
  paidVideos.add(paymentId);
  res.json({ success: true });
});

app.post('/api/generate-video', upload.array('images'), async (req, res) => {
  const { paymentId } = req.body;
  const isPaid = paidVideos.has(paymentId);
  const files = req.files;
  const outputVideo = `output-${Date.now()}.mp4`;

  files.forEach((file, index) => {
    const newFilename = `uploads/img${String(index).padStart(3, '0')}.jpg`;
    fs.renameSync(file.path, newFilename);
  });

  const watermarkFilter = isPaid
    ? ''
    : "-vf drawtext=text='Free Version':fontcolor=white:fontsize=24:x=10:y=H-th-10";

  const ffmpegCommand = `ffmpeg -y -r 1 -i uploads/img%03d.jpg ${watermarkFilter} -c:v libx264 -vf fps=25 -pix_fmt yuv420p public/${outputVideo}`;

  exec(ffmpegCommand, (error, stdout, stderr) => {
    fs.readdirSync('uploads').forEach(file => fs.unlinkSync(`uploads/${file}`));

    if (error) {
      console.error('FFmpeg error:', error);
      return res.status(500).json({ error: 'Failed to generate video' });
    }

    return res.json({ videoUrl: `https://your-render-url.com/${outputVideo}` });
  });
});

app.use(express.static('public'));

app.listen(port, () => {
  console.log(`Server running on http://localhost:${port}`);
});