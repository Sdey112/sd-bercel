import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { loadStripe } from '@stripe/stripe-js';

const stripePromise = loadStripe('pk_test_your_stripe_publishable_key');

export default function PhotoToVideo() {
  const [images, setImages] = useState([]);
  const [videoURL, setVideoURL] = useState(null);
  const [loading, setLoading] = useState(false);
  const [paymentId, setPaymentId] = useState(null);

  const handleImageUpload = (e) => {
    const files = Array.from(e.target.files);
    setImages(files);
  };

  const handlePayment = async () => {
    const stripe = await stripePromise;
    const res = await fetch('https://your-backend-url.com/api/create-payment-intent', {
      method: 'POST',
    });
    const { clientSecret } = await res.json();

    const result = await stripe.confirmCardPayment(clientSecret, {
      payment_method: {
        card: {
          token: 'tok_visa', // test token (for dev only)
        },
      },
    });

    if (result.paymentIntent?.id) {
      setPaymentId(result.paymentIntent.id);
      await fetch('https://your-backend-url.com/api/confirm-payment', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ paymentId: result.paymentIntent.id }),
      });
      alert('Payment successful!');
    } else {
      alert('Payment failed.');
    }
  };

  const handleSubmit = async () => {
    const formData = new FormData();
    images.forEach((img) => formData.append('images', img));
    if (paymentId) formData.append('paymentId', paymentId);

    setLoading(true);
    const res = await fetch('https://your-backend-url.com/api/generate-video', {
      method: 'POST',
      body: formData,
    });
    const data = await res.json();
    setVideoURL(data.videoUrl);
    setLoading(false);
  };

  return (
    <div className="max-w-2xl mx-auto p-4">
      <h1 className="text-2xl font-bold mb-4">SD BERCEL – AI Photo to Video Generator</h1>
      <input type="file" accept="image/*" multiple onChange={handleImageUpload} className="mb-4" />
      <div className="flex gap-2 mb-4">
        <Button onClick={handleSubmit} disabled={images.length === 0 || loading}>
          {loading ? 'Generating...' : 'Create Free Video (with watermark)'}
        </Button>
        <Button onClick={handlePayment} disabled={images.length === 0}>
          Remove Watermark ($3)
        </Button>
      </div>
      {videoURL && (
        <div className="mt-6">
          <h2 className="text-xl font-semibold mb-2">Your Video:</h2>
          <video controls src={videoURL} className="w-full rounded shadow" />
        </div>
      )}
    </div>
  );
}